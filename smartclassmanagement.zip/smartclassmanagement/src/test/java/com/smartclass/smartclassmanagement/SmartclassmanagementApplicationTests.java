package com.smartclass.smartclassmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartclassmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
